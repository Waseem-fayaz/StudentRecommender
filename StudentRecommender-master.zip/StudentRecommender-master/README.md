# StudentRecommender
A system is needed which recommends the Placement Officer the students who have 0 backlog count and have overall percentage more than 60%. This system will help placement officer to further groom the recommended students and align them for the various companies’ placement requirements which comes to Campus
vist the link to witness working : https://youtu.be/f1khRnp6dz8 
